const controller = {};
const { Blog, BlogCategory, BlogComment } = require("../models"); // use for querying data from DB

controller.showBlogs = async (req, res) => {
	const categories = await BlogCategory.findAll({
		include: [{ model: Blog }],
	});

	const keyword = req.query.keyword;

	const options = {
		include: [{ model: BlogCategory }, { model: BlogComment }],
		where: {},
	};

	const category = req.query.category;
	const categoryId = isNaN(category) ? 0 : category;
	if (categoryId > 0) {
		categoryId;
	}

	const blogs = await Blog.findAll(options);

	const limit = 2;
	const page = isNaN(req.query.page) ? 1 : parseInt(req.query.page);
	const offset = (page - 1) * limit;
	const selectedBlogs = blogs.slice(offset, offset + limit);
	const pagination = {
		page,
		limit,
		totalRows: blogs.length,
		queryParams: req.query,
	};
	res.render("list", {
		blogs: selectedBlogs,
		pagination,
	});
};

controller.showBlogDetails = async (req, res) => {
	const categories = await BlogCategory.findAll({
		include: [{ model: Blog }],
	});

	const blogId = req.params.id;
	const id = isNaN(blogId) ? 1 : blogId;

	const blogDetails = await Blog.findOne({
		include: [
			{ model: BlogCategory },
			{ model: BlogComment, order: [["createdAt", "ASC"]] },
		],
		where: { id },
	});

	res.render("detail", {
		blogDetails,
		categories,
	});
};

module.exports = controller;

// const controller = {};

// const { Blog, Comment, Category, User, Tag, sequelize } = require("../models");
// const { Op } = require("sequelize");

// controller.showBlogList = async (req, res) => {
// 	const include = [
// 		{
// 			model: Comment,
// 		},
// 	];

// 	const where = {};

// 	const keyword = req.query.keyword ? req.query.keyword.trim() : "";
// 	if (keyword !== "") {
// 		where.title = { [Op.iLike]: `%${keyword}%` };
// 	}

// 	const category = req.query.category;
// 	const categoryId = isNaN(category) ? 0 : parseInt(category);
// 	if (categoryId > 0) {
// 		where.categoryId = categoryId;
// 	}

// 	const tag = req.query.tag;
// 	const tagId = isNaN(tag) ? 0 : parseInt(tag);
// 	if (tagId > 0) {
// 		include.push({ model: Tag, where: { id: tagId } });
// 	}

// 	const blogs = await Blog.findAll({
// 		attributes: [
// 			"id",
// 			"title",
// 			"description",
// 			"imagePath",
// 			"summary",
// 			"updatedAt",
// 		],
// 		include,
// 		where,
// 	});

// 	const limit = 2;
// 	const page = isNaN(req.query.page) ? 1 : parseInt(req.query.page);
// 	const offset = (page - 1) * limit;
// 	const selectedBlogs = blogs.slice(offset, offset + limit);
// 	const pagination = { page, limit, totalRows: blogs.length, queryParams: req.query };

// 	res.render("blogs", {
// 		blogs: selectedBlogs,
// 		pagination,
// 	});
// };

// controller.showDetails = async (req, res) => {
// 	const idParam = Number(req.params.id);
// 	const id =
// 		isNaN(idParam) || !Number.isInteger(idParam) || idParam < 0 ? 0 : idParam;

// 	const blogDetails = await Blog.findOne({
// 		where: { id },
// 		include: [
// 			{ model: User },
// 			{ model: Comment },
// 			{ model: Category },
// 			{ model: Tag },
// 		],
// 	});

// 	res.render("details", {
// 		blogDetails,
// 	});
// };

// module.exports = controller;

// SEARCH WITH OR

// models.Model-Name-Here.findAll({
// 	where: {
// 		[Op.or]: {
// 			title: {
// 				[Op.iLike]: `%${keyword}%`
// 			},
// 			description: {
// 				[Op.iLike]: `%${keyword}%`
// 			}
// 		}
// 	}
// })
