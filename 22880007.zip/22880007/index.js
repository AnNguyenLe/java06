const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;
const expressHbs = require("express-handlebars");
const { createPagination } = require("express-handlebars-paginate");

const path = require("path");

app.use(express.static(path.join(__dirname, "/html")));
app.engine(
	"hbs",
	expressHbs.engine({
		extname: "hbs",
		defaultLayout: path.join(__dirname, "/views/layouts/layout.hbs"),
		layoutsDir: path.join(__dirname, "/views/layouts"),
		partialsDir: path.join(__dirname, "/views/partials"),
		runtimeOptions: {
			allowProtoPropertiesByDefault: true,
		},
		helpers: {
			formatDate(date) {
				return date.toLocaleDateString("en-US", {
					day: "numeric",
					month: "short",
					year: "numeric",
				});
			},
			createPagination,
		},
	})
);
app.set("view engine", "hbs");

// Trang chu: /, 
// Trang blogs list: /list
// Trang blog chi tiet: /list/:id

app.get("/", (req, res) => {
	res.render("index");
});

app.use("/list", require("./routes/router"))

app.listen(PORT, () => {
	console.log(`Server is listening at port ${PORT}...`);
});
